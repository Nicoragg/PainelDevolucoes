        <footer class="login-footer">
            <small>© <?= date("Y") ?> Sistema de Controle de Devoluções</small>
        </footer>

<p class="versao">Desenvolvido por Nicolas - Versão v1.0</p>